package template;

public abstract class Island {
	
	abstract void drawTree();
	abstract void drawHuts();
	abstract void drawWildLife();
	
	public final void draw() {
	
		drawTree();
		drawHuts();
		drawWildLife();
	}

}
