package template;

public class DrawIsland extends Island{

	@Override
	void drawTree() {
		// TODO Auto-generated method stub
		System.out.println("Draw trees of this isLand");
	}

	@Override
	void drawHuts() {
		// TODO Auto-generated method stub
		System.out.println("Draw huts of this isLand");
	}

	@Override
	void drawWildLife() {
		// TODO Auto-generated method stub
		System.out.println("Draw wild Life of this isLand");
	}

}
