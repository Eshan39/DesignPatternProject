package template;

public class Main {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		Island iland= new DrawIsland();
		iland.draw();
	}

}
