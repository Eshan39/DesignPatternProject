package observer;

public class Flora  extends Island{ 
	
	
	public Flora(DisasterManagementOffice disaster) {
		
		this.disaster=disaster;
		this.disaster.attach(this);
	}

	@Override
	public void update() {
		// TODO Auto-generated method stub
		System.out.println("In flora "+disaster.getNews());
	}

}
