package observer;

public class Environment extends Island{

	public Environment(DisasterManagementOffice disaster) {
		
		this.disaster=disaster;
		this.disaster.attach(this);
	}

	public void update() {
		// TODO Auto-generated method stub
		System.out.println("In this environment "+disaster.getNews());
	}

}
