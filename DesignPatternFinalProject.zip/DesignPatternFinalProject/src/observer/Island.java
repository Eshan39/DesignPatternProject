package observer;

public abstract class Island {
	
	DisasterManagementOffice disaster;
	public abstract void update();
}
