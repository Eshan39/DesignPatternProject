package observer;

public class Main {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		DisasterManagementOffice disaster= new DisasterManagementOffice();
		
		new Flora(disaster);
		new Fona(disaster);
		new Environment(disaster);
		disaster.setNews("Storm Foni is going to attack at midnight");
	}

}
