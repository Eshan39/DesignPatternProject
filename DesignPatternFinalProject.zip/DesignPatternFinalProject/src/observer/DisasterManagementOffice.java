package observer;

import java.util.ArrayList;
import java.util.List;

public class DisasterManagementOffice {

	private String news;
	private List<Island> isLand = new ArrayList<Island>();

	   public String getNews() {
	      return news;
	   }

	   public void setNews(String news) {
	      this.news = news;
	      notifyAllIslands();
	   }

	   public void attach(Island isLands){
	      isLand.add(isLands);	
	   }

	   public void notifyAllIslands(){
	      for (Island isLands : isLand) {
	         isLands.update();
	      }
	   } 	
}
