package observer;

public class Fona extends Island {

	public Fona(DisasterManagementOffice disaster) {
		
		this.disaster=disaster;
		this.disaster.attach(this);
	}

	public void update() {
		// TODO Auto-generated method stub
		System.out.println("In flora "+disaster.getNews());
	}

}
