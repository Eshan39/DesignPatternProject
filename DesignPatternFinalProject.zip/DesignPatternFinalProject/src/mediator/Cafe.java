package mediator;

public class Cafe {
	
	public static void info(CityPeople people, String information) {
	
		System.out.println(" "+people.getPeople()+" "+information);
	}

	public static void info(IslandPeople islandPeople, String information) {
		// TODO Auto-generated method stub
		System.out.println(" "+((IslandPeople) islandPeople).getPeople()+" "+ information);
	}

}
