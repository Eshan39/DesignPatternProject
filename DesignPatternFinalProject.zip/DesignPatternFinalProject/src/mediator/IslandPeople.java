package mediator;

public class IslandPeople {
	
	private String islandPeople;
	
	public IslandPeople(String islandPeople) {
		this.islandPeople=islandPeople;
	}
	
	public String getPeople() {
		return islandPeople;
	}
	
	public void setPeople(String islandPeople) {
		this.islandPeople=islandPeople;
	}
	
	public void sendInfor(String information){
	    Cafe.info(this,information);
	}

	
}
