package mediator;

public class CityPeople {

	private String cityPeople;
	
	public CityPeople(String cityPeople) {
		this.cityPeople=cityPeople;
	}
	
	public String getPeople() {
		return cityPeople;
	}
	
	public void setPeople(String cityPeople) {
		this.cityPeople=cityPeople;
	}
	
	public void sendInfor(String information){
	    Cafe.info(this,information);
	}
}
