package mediator;

public class Main {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		CityPeople people = new CityPeople("Niraj,"); 
		people.sendInfor("City people are in danger. Storm fonni is coming very soon");
		
		
		IslandPeople isPeople= new IslandPeople("David Malan,");
		isPeople.sendInfor("Island is under attack of Finland.");
		
	}

}
