package facade;

public class Environment  implements Island{

	@Override
	public void draw() {
		// TODO Auto-generated method stub
		System.out.println("Draw huts.");
	}

}
