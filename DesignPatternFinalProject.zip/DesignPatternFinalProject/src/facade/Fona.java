package facade;

public class Fona implements Island {

	@Override
	public void draw() {
		// TODO Auto-generated method stub
		System.out.println("Draw wildlife");
	}

}
