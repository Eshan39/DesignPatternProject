package facade;

public class FacadeMaker {
	
	Island flora;
	Island fona;
	Island environment;
	
	public FacadeMaker(){
		flora= new Flora();
		fona =  new Fona();
		environment = new Environment();
	}

	public void drawFlora(){
		flora.draw();
	}
	public void drawFona() {
		fona.draw();
	}
	public void drawEnvironment() {
		environment.draw();
	}
}
