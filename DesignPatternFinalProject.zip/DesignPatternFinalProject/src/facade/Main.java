package facade;

public class Main {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		FacadeMaker facade= new FacadeMaker();
		facade.drawFlora();
		facade.drawFona();
		facade.drawEnvironment();
		
	}
}
