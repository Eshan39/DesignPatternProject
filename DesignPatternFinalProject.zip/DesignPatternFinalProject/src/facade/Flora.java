package facade;

public class Flora  implements Island{

	@Override
	public void draw() {
		// TODO Auto-generated method stub
		System.out.println("Draw trees");
	}

}
