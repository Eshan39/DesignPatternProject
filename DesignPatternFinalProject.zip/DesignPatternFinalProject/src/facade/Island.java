package facade;

public interface Island {

	public void draw();
}
