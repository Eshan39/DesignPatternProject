package mementoMarriage;

public class Memento {

	String marriage;
	
	public Memento(String marriage) {
		
		this.marriage=marriage;
	} 
	
	public String getMarriage() {
		return marriage;
	}
}
