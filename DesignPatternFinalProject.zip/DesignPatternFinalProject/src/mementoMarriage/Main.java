package mementoMarriage;

public class Main {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
	     Originator originator = new Originator();
	     CareTaker careTaker = new CareTaker();
	     
	     originator.setMarriage("They are perfect couple: niraj and Rai");
	     careTaker.add(originator.saveToPriestList());
	     
	     originator.setMarriage("Musa and afsana are not vows. Break their bond");
	     
	     originator.getMarriageInfoFromPriestList(careTaker.get(0));
	     System.out.println(originator.getMarriage());

	}

}
