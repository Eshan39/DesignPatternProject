package mementoMarriage;

public class Originator {

	String marriage;
	
	public void setMarriage(String marriage) {	
		this.marriage=marriage;
	}
	
	public String getMarriage() {
		return marriage;
	}
	
	public Memento saveToPriestList() {
		return new Memento(marriage);
	}
	
	public void getMarriageInfoFromPriestList(Memento memento) {
		marriage= memento.getMarriage();
	}
	
	
}
