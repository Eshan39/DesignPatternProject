package abstractFactory;

public class Flora  implements Island{

	@Override
	public void contain() {
		// TODO Auto-generated method stub
		System.out.println("Contains some plant of various height.");
	}

}
