package abstractFactory;

public class DangerousEnvironment implements Island{

	@Override
	public void contain() {
		// TODO Auto-generated method stub
		System.out.println("Donot enter inside this area.It's a danger zone");
	}

}
