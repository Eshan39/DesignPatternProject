package abstractFactory;

public class DangerousIslandFactory extends AbstractFactory{

	public Island getIsland(String test) {
		
		if(test=="fona") {
			return new DangerousFona();
		}
		else if (test=="environment") {
			return new DangerousEnvironment();
		}
		
		return null;
			
	}
}
