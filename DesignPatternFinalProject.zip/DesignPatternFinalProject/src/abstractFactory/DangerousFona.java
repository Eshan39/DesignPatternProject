package abstractFactory;

public class DangerousFona implements Island{

	@Override
	public void contain() {
		// TODO Auto-generated method stub
		System.out.println("This animals are theaten to exist.");
	}

}
