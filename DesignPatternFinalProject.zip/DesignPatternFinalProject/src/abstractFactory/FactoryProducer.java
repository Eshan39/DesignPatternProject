package abstractFactory;

public class FactoryProducer {
	   public static AbstractFactory getFactory(boolean danger){   
	      if(danger){
	         return new DangerousIslandFactory();         
	      }else{
	         return new IslandFactory();
	      }
	  }
}