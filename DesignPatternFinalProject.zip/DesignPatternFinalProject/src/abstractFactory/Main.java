package abstractFactory;

public class Main {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		AbstractFactory factory= FactoryProducer.getFactory(true);
		
		Island fona= factory.getIsland("fona");
		fona.contain();
		
		Island environment= factory.getIsland("environment");
		environment.contain();
		
		
		AbstractFactory isFactory= FactoryProducer.getFactory(false);
		
		Island isFona= isFactory.getIsland("fona");
		isFona.contain();
		
		Island env= isFactory.getIsland("environment");
		env.contain();

	}

}
