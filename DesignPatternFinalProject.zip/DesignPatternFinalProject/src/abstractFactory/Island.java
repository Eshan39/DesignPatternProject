package abstractFactory;

public interface Island {

	public void contain();
}
