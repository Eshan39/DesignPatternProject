package abstractFactory;

public abstract class AbstractFactory {

	abstract Island getIsland(String test);
}
