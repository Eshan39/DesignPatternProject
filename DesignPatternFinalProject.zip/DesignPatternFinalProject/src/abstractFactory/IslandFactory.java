package abstractFactory;

public class IslandFactory extends AbstractFactory{

	public Island getIsland(String test) {
		
		if(test==null) {
			return null;
		}
		
		if(test=="flora") {
			return new Flora();
		}
		else if(test=="fona") {
			return new Fona();
		}
		else if(test=="environment") {
			return new Environment();
		}
		
		return null;
			
	}
}
