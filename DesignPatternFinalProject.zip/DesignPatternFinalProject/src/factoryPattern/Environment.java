package factoryPattern;

public class Environment  implements Island{

	@Override
	public void contain() {
		// TODO Auto-generated method stub
		System.out.println("Containing some huts made of differnt objects. Draw huts.");
	}

}
