package factoryPattern;

public interface Island {

	public void contain();
}
