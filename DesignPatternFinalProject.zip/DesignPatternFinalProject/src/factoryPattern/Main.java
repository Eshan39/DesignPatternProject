package factoryPattern;

public class Main {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		IslandFactory factory= new IslandFactory();
		
		Island flora= factory.getIsland("flora");
		flora.contain();
		
		Island fona= factory.getIsland("fona");
		fona.contain();
		
		Island env= factory.getIsland("environment");
		env.contain();

	}

}
