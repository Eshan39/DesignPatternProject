package factoryPattern;

public class Fona implements Island {

	@Override
	public void contain() {
		// TODO Auto-generated method stub
		System.out.println("Contains some animals including wild animal. Draw wildlife");
	}

}
