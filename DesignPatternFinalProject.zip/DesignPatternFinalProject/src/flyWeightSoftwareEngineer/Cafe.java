package flyWeightSoftwareEngineer;

public class Cafe implements City{
	
	private String name;
	
	public Cafe(String name) {
		
		this.name=name;
	}
	
	public void setName(String name) {
		
		this.name=name;
	}

	@Override
	public void nameList() {
		// TODO Auto-generated method stub
		System.out.println("The software engineer "+ name+" have access to cafe.");
		
	}
	

}
