package flyWeightSoftwareEngineer;

public class Main {

	   private static final String names[] = { "Eshan", "Rifat", "Musa", "Niraj", "Rifad" };
	   
	   public static void main(String[] args) {

	      for(int i=0; i < 10; ++i) {
	         Cafe cafe = (Cafe)FlyWeight.getCafe(getRandomName());
	         cafe.nameList();
	      }
	   }
	   
	   private static String getRandomName() {
	      return names[(int)(Math.random()*names.length)];
	   }

}
