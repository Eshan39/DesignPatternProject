package flyWeightSoftwareEngineer;

public interface City {
	
	void nameList();
}
