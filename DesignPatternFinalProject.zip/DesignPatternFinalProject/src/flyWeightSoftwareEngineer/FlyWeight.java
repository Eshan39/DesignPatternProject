package flyWeightSoftwareEngineer;

import java.util.HashMap;

public class FlyWeight {
	
	   private static final HashMap cafeMap = new HashMap();

	   public static City getCafe(String name) {
	      Cafe cafe = (Cafe)cafeMap.get(name);

	      if(cafe == null) {
	         cafe = new Cafe(name);
	         cafeMap.put(name, cafe);
	         System.out.println("Name of Software Engineer : " + name);
	      }
	      return cafe;
	   }

}
