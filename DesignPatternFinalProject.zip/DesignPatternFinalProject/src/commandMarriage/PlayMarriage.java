package commandMarriage;

public class PlayMarriage {
	
	 public static Vows getVows(){
		 return new Marriage();
	 }
}
