package commandMarriage;


import java.util.ArrayList;


public class AllMarriageBreak implements Command{
	
	ArrayList<Vows> theVows;
	
	public AllMarriageBreak(ArrayList<Vows> theVows){
	
		this.theVows=theVows;
	}

	@Override
	public void execute() {
		// TODO Auto-generated method stub
		for(Vows vows: theVows) {
			vows.breakBond();
		}
	}

	@Override
	public void undo() {
		// TODO Auto-generated method stub
		for(Vows vows: theVows) {
			vows.bond();
		}
	}

}
