package commandMarriage;

public class BondVows implements Command{
	
	Vows vows;
	
	public BondVows(Vows vows) {
		this.vows=vows;
	}

	@Override
	public void execute() {
		// TODO Auto-generated method stub
		vows.bond();
	}

	@Override
	public void undo() {
		// TODO Auto-generated method stub
		vows.breakBond();
	}

	

}
