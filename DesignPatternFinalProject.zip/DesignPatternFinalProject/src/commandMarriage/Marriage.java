package commandMarriage;

public class Marriage implements Vows {

	@Override
	public void bond() {
		// TODO Auto-generated method stub
		System.out.println("They are perfect match");
	}

	@Override
	public void breakBond() {
		// TODO Auto-generated method stub
		System.out.println("Mismatch, please break the bond");
		
	}

}
