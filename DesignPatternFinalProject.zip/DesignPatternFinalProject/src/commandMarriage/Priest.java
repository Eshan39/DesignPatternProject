package commandMarriage;

public class Priest {

	Command command;
	
	public Priest(Command command){
	
		this.command=command;
	}
	
	public void match()
	{
		command.execute();
	}
	public void misMatch() {
		command.undo();
	}
}
