package commandMarriage;

public interface Vows {
	public void bond();
	public void breakBond();
}
