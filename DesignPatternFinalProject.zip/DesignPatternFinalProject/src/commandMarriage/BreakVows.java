package commandMarriage;

public class BreakVows implements Command {

	Vows vows;
	
	public BreakVows(Vows vows) {
		this.vows=vows;
	}

	@Override
	public void execute() {
		// TODO Auto-generated method stub
		vows.breakBond();
	}

	@Override
	public void undo() {
		// TODO Auto-generated method stub
		vows.bond();
		
	}
}
