package commandMarriage;

import java.awt.List;
import java.util.ArrayList;

public class Main {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		Vows newVows= PlayMarriage.getVows();
		
		BondVows bVows= new BondVows(newVows);
		Priest priest= new Priest(bVows);
		priest.match();
		priest.misMatch();
		
		BreakVows breakVows = new BreakVows(newVows);
		priest= new Priest(breakVows);
		//priest.match();
		
		Marriage mar = new Marriage();
		ArrayList<Vows> allVows = new ArrayList<Vows>();
		allVows.add(mar);
		 
		AllMarriageBreak all = new AllMarriageBreak(allVows);
		priest= new Priest(all);
		//priest.match();
		//priest.misMatch();
		 
	}

}
