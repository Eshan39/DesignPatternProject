package singeltonWater;

public class WaterReservoir {
	
	private static WaterReservoir instance = new WaterReservoir();
	
	public static WaterReservoir getInstance(){
	      return instance;
	}

	public void waterStatus(int height) {
		
		if(height<5) {
			System.out.println("Pray for rain.");
		}
		else {
			System.out.println("Collect water");
			
		}
		
	}
}
