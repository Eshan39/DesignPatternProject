package singeltonWater;

import java.util.Scanner;

public class Main {
	
	public static void main(String []args) {
		
		int height;
		Scanner input=new Scanner(System.in);
		System.out.println("what is water level now");
		height=input.nextInt();
		
		WaterReservoir object= WaterReservoir.getInstance();
		object.waterStatus(height);
	}
}
